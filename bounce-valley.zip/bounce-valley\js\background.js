/* ============================================================
 * background.js — 多层视差背景（每主题程序化生成，原创素材）
 * Layer1 天空 → Layer2 远景 → Layer3 中景 → 动态前景粒子
 * ============================================================ */
window.BT = window.BT || {};

BT.Background = class {
  constructor(themeKey, seed) {
    this.themeKey = themeKey;
    this.th = BT.CFG.themes[themeKey];
    this.W = 2048; this.H = 1200;
    this.rng = BT.Utils.seededRandom(seed || this.th.parallaxSeed);
    this.build();
  }

  makeCanvas(w, h) {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    return c;
  }

  build() {
    /* ---- Layer 1: 天空渐变 ---- */
    this.skyC = this.makeCanvas(64, this.H);
    const sg = this.skyC.getContext('2d');
    const grad = sg.createLinearGradient(0, 0, 0, this.H);
    grad.addColorStop(0, this.th.skyTop);
    grad.addColorStop(1, this.th.skyBottom);
    sg.fillStyle = grad;
    sg.fillRect(0, 0, 64, this.H);

    /* ---- Layer 2: 远景 ---- */
    this.farC = this.makeCanvas(this.W, this.H);
    const f = this.farC.getContext('2d');
    if (this.themeKey === 'forest') this.ridge(f, this.W, this.H * 0.62, 210, this.th.farLayer, 5);
    else if (this.themeKey === 'cave') this.ridge(f, this.W, this.H * 0.55, 300, this.th.farLayer, 7);
    else { this.ridge(f, this.W, this.H * 0.55, 150, this.th.farLayer, 3); this.domes(f); }

    /* ---- Layer 3: 中景 ---- */
    this.midC = this.makeCanvas(this.W, this.H);
    const m = this.midC.getContext('2d');
    if (this.themeKey === 'forest') this.trees(m, this.th.midLayer, this.H * 0.7, 120, 26);
    else if (this.themeKey === 'cave') { this.ridge(m, this.W, this.H * 0.7, 170, this.th.midLayer, 11); this.stalactites(m, this.th.midLayer); }
    else this.columns(m, this.th.midLayer);

    /* 漂浮萤光（动态层用） */
    this.motes = [];
    for (let i = 0; i < 26; i++) {
      this.motes.push({
        x: this.rng() * this.W, y: this.rng() * this.H,
        s: 1.5 + this.rng() * 3, ph: this.rng() * BT.Utils.TAU, sp: 6 + this.rng() * 14,
      });
    }
    /* 云 */
    this.clouds = [];
    for (let i = 0; i < 7; i++) {
      this.clouds.push({ x: this.rng() * this.W, y: 90 + this.rng() * 260, s: 0.6 + this.rng() * 1.1, sp: 5 + this.rng() * 9 });
    }
  }

  /* 山脊剪影 */
  ridge(ctx, W, baseY, amp, color, steps) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(0, this.H);
    let y = baseY;
    for (let x = 0; x <= W; x += W / steps) {
      y = baseY - this.rng() * amp;
      ctx.lineTo(x, y);
      ctx.lineTo(x + W / steps / 2, baseY - amp * 0.4 - this.rng() * amp * 0.4);
    }
    ctx.lineTo(W, this.H);
    ctx.closePath(); ctx.fill();
  }

  /* 遗迹穹顶 */
  domes(ctx) {
    ctx.fillStyle = this.th.midLayer;
    for (let i = 0; i < 4; i++) {
      const x = this.rng() * this.W, r = 60 + this.rng() * 90, y = this.H * 0.62;
      ctx.beginPath(); ctx.arc(x, y, r, Math.PI, 0); ctx.fill();
      ctx.fillRect(x - r, y, r * 2, this.H - y);
    }
  }

  /* 远树 */
  trees(ctx, color, baseY, h, w) {
    ctx.fillStyle = color;
    for (let x = 20; x < this.W; x += 40 + this.rng() * 55) {
      const hh = h * (0.6 + this.rng() * 0.8);
      const ww = w * (0.7 + this.rng() * 0.6);
      ctx.beginPath();
      ctx.moveTo(x, baseY);
      ctx.lineTo(x + ww / 2, baseY - hh);
      ctx.lineTo(x + ww, baseY);
      ctx.closePath(); ctx.fill();
      ctx.fillRect(x + ww / 2 - 3, baseY - 12, 6, 14);
    }
  }

  /* 钟乳石 */
  stalactites(ctx, color) {
    ctx.fillStyle = color;
    for (let x = 30; x < this.W; x += 60 + this.rng() * 90) {
      const len = 70 + this.rng() * 200;
      const w = 24 + this.rng() * 40;
      ctx.beginPath();
      ctx.moveTo(x - w, 0);
      ctx.lineTo(x + w, 0);
      ctx.lineTo(x, len);
      ctx.closePath(); ctx.fill();
    }
  }

  /* 神庙柱廊 */
  columns(ctx, color) {
    ctx.fillStyle = color;
    for (let x = 60; x < this.W; x += 170 + this.rng() * 80) {
      const w = 34 + this.rng() * 20, h = 340 + this.rng() * 220, y = this.H - h;
      ctx.fillRect(x, y, w, h);
      ctx.fillRect(x - 10, y, w + 20, 22);      // 柱头
      ctx.fillRect(x - 8, this.H - 26, w + 16, 26); // 柱础
    }
  }

  /* 渲染（屏幕空间调用，cam 为摄像机） */
  draw(ctx, cam, viewW, viewH, time) {
    /* 天空 */
    ctx.drawImage(this.skyC, 0, 0, 64, this.H, 0, 0, viewW, viewH);

    /* 太阳 / 洞穴顶光 / 遗迹落日 */
    if (this.themeKey === 'forest') {
      ctx.fillStyle = 'rgba(255, 244, 180, .95)';
      ctx.beginPath(); ctx.arc(viewW * 0.78, viewH * 0.2, 58, 0, BT.Utils.TAU); ctx.fill();
      ctx.fillStyle = 'rgba(255, 244, 180, .25)';
      ctx.beginPath(); ctx.arc(viewW * 0.78, viewH * 0.2, 95, 0, BT.Utils.TAU); ctx.fill();
    } else if (this.themeKey === 'ruins') {
      const g = ctx.createRadialGradient(viewW * 0.72, viewH * 0.3, 10, viewW * 0.72, viewH * 0.3, 240);
      g.addColorStop(0, 'rgba(255,210,140,.9)');
      g.addColorStop(1, 'rgba(255,210,140,0)');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, viewW, viewH);
    }

    /* 远 / 中景平铺 */
    this.tileLayer(ctx, this.farC, cam.x * 0.12, cam.y * 0.05, viewW);
    this.tileLayer(ctx, this.midC, cam.x * 0.3, cam.y * 0.12, viewW);

    /* 动态元素 */
    if (this.themeKey === 'forest') {
      for (const c of this.clouds) {
        const x = ((c.x + time * c.sp - cam.x * 0.18) % (this.W + 400) + this.W + 400) % (this.W + 400) - 200;
        const y = c.y - cam.y * 0.06;
        ctx.fillStyle = 'rgba(255,255,255,.75)';
        ctx.beginPath();
        ctx.arc(x, y, 26 * c.s, 0, BT.Utils.TAU);
        ctx.arc(x + 30 * c.s, y - 10 * c.s, 20 * c.s, 0, BT.Utils.TAU);
        ctx.arc(x + 58 * c.s, y, 22 * c.s, 0, BT.Utils.TAU);
        ctx.fill();
      }
    }
    /* 萤光/浮尘 */
    for (const mte of this.motes) {
      const x = ((mte.x + Math.sin(time * 0.4 + mte.ph) * 40 - cam.x * 0.4) % this.W + this.W) % this.W;
      const y = ((mte.y + Math.cos(time * 0.3 + mte.ph) * 30 - cam.y * 0.3) % this.H + this.H) % this.H;
      const a = 0.25 + Math.sin(time * mte.sp * 0.1 + mte.ph) * 0.2;
      ctx.globalAlpha = Math.max(0.05, a);
      ctx.fillStyle = this.themeKey === 'cave' ? '#7ee7ff' : (this.themeKey === 'ruins' ? '#ffd9a0' : '#fff6c9');
      ctx.beginPath(); ctx.arc(x * viewW / this.W * 2 % viewW, y * viewH / this.H * 1.2 % viewH, mte.s, 0, BT.Utils.TAU);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  tileLayer(ctx, canvas, offX, offY, viewW) {
    const x = -(((offX % this.W) + this.W) % this.W);
    const y = -BT.Utils.clamp(offY, -140, 140);
    ctx.drawImage(canvas, x, y);
    if (x + this.W < viewW) ctx.drawImage(canvas, x + this.W, y);
    if (x > 0) ctx.drawImage(canvas, x - this.W, y);
  }
};
