/* ============================================================
 * ui.js — UI 管理器
 * 主菜单 / 关卡选择 / 设置 / 关于 / 暂停 / 通关结算 / HUD /
 * Toast 提示 / 触屏按钮显隐
 * ============================================================ */
window.BT = window.BT || {};

BT.UIManager = class {
  constructor(game) {
    this.game = game;
    this.$ = (id) => document.getElementById(id);
    this.settingsReturn = 'main';   // 设置页返回目标
    this.screens = {
      main: 'mainMenu', select: 'levelSelect', settings: 'settingsPanel',
      about: 'aboutPanel', pause: 'pauseMenu', complete: 'levelComplete',
    };
    this.bind();
    this.applySettings();
    this.drawTitleBall();
  }

  /* ---------------- 界面切换 ---------------- */
  showScreen(name) {
    for (const k in this.screens) {
      this.$(this.screens[k]).classList.toggle('hidden', k !== name);
    }
  }

  showHUD(on) {
    this.$('hud').classList.toggle('hidden', !on);
    this.$('toastBox').classList.toggle('hidden', !on || !this._hasToast);
    this.updateTouchVisible();
  }

  /* ---------------- HUD ---------------- */
  updateHUD() {
    const g = this.game;
    if (!g.level) return;
    this.$('orbText').textContent = `${g.orbCount} / ${g.level.totalOrbs}`;
    this.$('timeText').textContent = BT.Utils.fmtTime(g.timer);
    this.$('deathText').textContent = '💀 ' + g.deaths;
    this.$('levelName').textContent = `LEVEL ${g.levelIndex + 1} · ${g.level.name}`;
  }

  toast(text, ms = 2400) {
    const box = this.$('toastBox');
    box.classList.remove('hidden');
    this._hasToast = true;
    const el = document.createElement('div');
    el.className = 'toast';
    el.textContent = text;
    box.appendChild(el);
    setTimeout(() => { el.remove(); if (!box.children.length) { box.classList.add('hidden'); this._hasToast = false; } }, ms);
  }

  /* ---------------- 通关结算 ---------------- */
  showLevelComplete({ levelId, name, time, orbs, total, deaths, newRecord, hasNext }) {
    this.$('lcTitle').textContent = `LEVEL ${levelId} COMPLETE!`;
    this.$('lcTime').textContent = BT.Utils.fmtTime(time);
    this.$('lcOrbs').textContent = `${orbs} / ${total}`;
    this.$('lcDeaths').textContent = String(deaths);
    this.$('lcNewRecord').classList.toggle('hidden', !newRecord);
    const next = this.$('btnNext');
    next.classList.toggle('hidden', !hasNext);
    this.showScreen('complete');
  }

  /* ---------------- 关卡选择 ---------------- */
  buildLevelGrid() {
    const grid = this.$('levelGrid');
    grid.innerHTML = '';
    BT.LEVELS.forEach((def, i) => {
      const unlocked = BT.save.isUnlocked(i + 1);
      const best = BT.save.getBest(i + 1);
      const card = document.createElement('div');
      card.className = 'level-card' + (unlocked ? '' : ' locked');
      card.dataset.theme = def.theme;
      card.innerHTML = `
        <div class="lc-num">${i + 1}</div>
        <div class="lc-name">${def.name}</div>
        <div class="lc-best">${best
          ? `能量球 ${best.orbs}/${best.total}<br>最快 ${BT.Utils.fmtTime(best.time)}`
          : (unlocked ? '尚未通关' : '完成上一关解锁')}</div>
        ${unlocked ? '' : '<div class="lc-lock">🔒</div>'}`;
      if (unlocked) card.addEventListener('click', () => { BT.audio.sfx('click'); this.game.startLevel(i); });
      grid.appendChild(card);
    });
  }

  /* ---------------- 设置 ---------------- */
  applySettings() {
    const s = BT.save.settings;
    this.$('musicRange').value = Math.round(s.music * 100);
    this.$('musicVal').textContent = Math.round(s.music * 100);
    this.$('sfxRange').value = Math.round(s.sfx * 100);
    this.$('sfxVal').textContent = Math.round(s.sfx * 100);
    this.$('touchSel').value = s.touch;
    BT.audio.setMusicVolume(s.music);
    BT.audio.setSfxVolume(s.sfx);
    this.updateTouchVisible();
  }

  updateTouchVisible() {
    const mode = BT.save.settings.touch;
    const coarse = window.matchMedia('(pointer: coarse)').matches || ('ontouchstart' in window);
    const playing = this.game.state === 'playing';
    const show = playing && (mode === 'on' || (mode === 'auto' && coarse));
    this.$('touchControls').classList.toggle('hidden', !show);
  }

  /* ---------------- 标题小球 ---------------- */
  drawTitleBall() {
    const cv = this.$('titleBall');
    const ctx = cv.getContext('2d');
    const r = 52;
    ctx.save();
    ctx.translate(75, 78);
    const g = ctx.createRadialGradient(-r * 0.35, -r * 0.4, r * 0.15, 0, 0, r);
    g.addColorStop(0, '#ff8a6b'); g.addColorStop(0.35, '#e8402a'); g.addColorStop(1, '#a81f12');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(0, 0, r, 0, BT.Utils.TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(90,10,5,.55)'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.arc(0, 0, r - 2, 0, BT.Utils.TAU); ctx.stroke();
    /* 眼睛 */
    for (const side of [-1, 1]) {
      ctx.fillStyle = '#fff';
      ctx.beginPath(); ctx.ellipse(side * 20, -10, 13, 15, 0, 0, BT.Utils.TAU); ctx.fill();
      ctx.fillStyle = '#22160f';
      ctx.beginPath(); ctx.arc(side * 20, -6, 6.5, 0, BT.Utils.TAU); ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.beginPath(); ctx.arc(side * 20 - 2.5, -8.5, 2.2, 0, BT.Utils.TAU); ctx.fill();
    }
    /* 腮红 + 嘴 */
    ctx.fillStyle = 'rgba(255,130,100,.4)';
    for (const side of [-1, 1]) { ctx.beginPath(); ctx.ellipse(side * 34, 8, 8, 5, 0, 0, BT.Utils.TAU); ctx.fill(); }
    ctx.strokeStyle = '#5a100a'; ctx.lineWidth = 4; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.arc(0, 8, 12, 0.25 * Math.PI, 0.75 * Math.PI); ctx.stroke();
    ctx.restore();
  }

  /* ---------------- 事件绑定 ---------------- */
  bind() {
    /* 鼠标点击任意位置也解锁音频（首次交互） */
    document.addEventListener('pointerdown', () => {
      if (this.game && !this.game._audioReady) {
        BT.audio.unlock();
        this.game.onAudioUnlocked();
      }
    }, { capture: true });

    const on = (id, fn) => this.$(id).addEventListener('click', (e) => {
      BT.audio.sfx('click'); fn(e);
    });

    on('btnPlay', () => {
      /* 从最高已解锁关卡开始 */
      const idx = BT.Utils.clamp(BT.save.data.unlocked - 1, 0, BT.LEVELS.length - 1);
      this.game.startLevel(idx);
    });
    on('btnLevelSelect', () => { this.buildLevelGrid(); this.showScreen('select'); });
    on('btnSettings', () => { this.settingsReturn = 'main'; this.showScreen('settings'); });
    on('btnAbout', () => this.showScreen('about'));
    on('btnBackMain', () => this.showScreen('main'));
    on('btnBackAbout', () => this.showScreen('main'));
    on('btnBackSettings', () => this.showScreen(this.settingsReturn === 'pause' ? 'pause' : 'main'));

    /* 设置项 */
    this.$('musicRange').addEventListener('input', (e) => {
      const v = e.target.value / 100;
      BT.save.setSetting('music', v);
      BT.audio.setMusicVolume(v);
      this.$('musicVal').textContent = e.target.value;
    });
    this.$('sfxRange').addEventListener('input', (e) => {
      const v = e.target.value / 100;
      BT.save.setSetting('sfx', v);
      BT.audio.setSfxVolume(v);
      this.$('sfxVal').textContent = e.target.value;
      BT.audio.sfx('orb');
    });
    this.$('touchSel').addEventListener('change', (e) => {
      BT.save.setSetting('touch', e.target.value);
      this.updateTouchVisible();
    });
    on('btnResetSave', () => {
      if (confirm('确定清除全部存档（解锁进度与纪录）吗？')) {
        BT.save.reset();
        this.applySettings();
        this.toast('存档已清除');
      }
    });

    /* 暂停菜单 */
    on('btnResume', () => this.game.resume());
    on('btnRestartPause', () => this.game.restartLevel());
    on('btnSettingsPause', () => { this.settingsReturn = 'pause'; this.showScreen('settings'); });
    on('btnQuitToMenu', () => this.game.toMenu());

    /* 通关结算 */
    on('btnNext', () => this.game.nextLevel());
    on('btnRetry', () => this.game.restartLevel());
    on('btnMenuLC', () => this.game.toMenu());
  }
};
